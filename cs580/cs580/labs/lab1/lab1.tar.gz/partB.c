#include<stdio.h>
void main(){

long int large_num = 9838263505978427528;

double no1= (double)large_num;
char c = (char)large_num;


printf("\n \t Integer:  \t  %d",large_num);
printf("\n \t Float : \t %f",no1);
printf("\n \t Float : \t %e",no1);
printf("\n \t Character: \t %c",c);



printf("\n");

}
